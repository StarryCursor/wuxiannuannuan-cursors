﻿无限暖暖-01 Windows 鼠标指针包
作者: [StarryCursor](https://github.com/StarryCursor)
================================================

【安装步骤】
1. 右键单击 install.inf
   (Windows 11 用户：先点"显示更多选项"或按 Shift+F10)
2. 在菜单里点"安装"
3. 弹出 UAC 权限请求时，点"是"
4. 按 Win+R 输入 main.cpl 回车，打开"鼠标 属性"
5. 切换到"指针"标签
6. 在"方案"下拉框里选"无限暖暖-01"
7. 点"确定"，所有 11 个光标立即生效

【常见问题】
- 右键菜单里找不到"安装"？
  Windows 11 需要先点"显示更多选项"，或按 Shift+F10 调出旧版菜单。

- UAC 弹窗一闪就消失？
  可能是账户不是管理员，或被杀毒软件拦截。
  切换到管理员账户重试，或临时关闭杀毒软件。

- 下拉框里没看到"无限暖暖-01"？
  可能是 INF 没装上。试试用管理员身份打开 cmd，
  cd 到 INF 所在目录，运行：
    rundll32.exe setupapi.dll,InstallHinfSection DefaultInstall 132 .\install.inf

【包含的 11 个光标】
arrow.cur          正常箭头
ibeam.cur          文本选择
link.cur           链接选择
busy.cur           忙碌 / 工作中
unavail.cur        不可用
move.cur           移动
size_ns.cur        垂直调整 ↕
size_we.cur        水平调整 ↔
size_nesw.cur      对角调整 2 (NE-SW) ↗↙
size_nwse.cur      对角调整 1 (NW-SE) ↖↘
closedhand.cur     拖拽（Windows 标准方案不含此槽位）

每个 .cur 内嵌 5 种分辨率 (32/48/64/96/128)，自适应 100%~300% 显示缩放。

【卸载】
1. Win+R 输入 main.cpl，"方案"下拉框选"Windows 默认"
2. 用管理员身份打开 cmd，运行:
   rmdir /S /Q "%SystemRoot%\Cursors\NuanNuan-01"
   reg delete "HKCU\Control Panel\Cursors\Schemes" /v "无限暖暖-01" /f
